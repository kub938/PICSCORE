// import { api } from "../api/api";

// interface GoogleVisionResponse {
//   cropHints?: any;
//   imagePropertiesAnnotation?: any;
//   faceAnnotations?: any;
//   labelAnnotations?: any;
//   [key: string]: any;
// }

// export function analyzeWithGoogleVision(
//   inageUri: string
// ): Promise<GoogleVisionResponse> {
//   return;
// }
