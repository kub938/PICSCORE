import { Share } from "lucide-react";
import processResult from "../../assets/ImageEval/process-result.svg";
import Button from "../../components/Button";
import testImage from "../../assets/ImageEval/test-image.jpg";

import {
  MagnifyingGlassIcon,
  ArrowUpTrayIcon,
  ShareIcon,
} from "@heroicons/react/24/solid";
import { useState } from "react";
import ImageEvalDetail from "./ImageEvalDetail";

function ImageEvalResult() {
  const score = 84;
  const [isModalOpen, setIsModalOpen] = useState(false);

  const openModal = () => {
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
  };

  return (
    <div className="flex flex-col items-center justify-center ">
      <ImageEvalDetail
        isModalOpen={isModalOpen}
        closeModal={closeModal}
        score={score}
      />

      <img src={processResult} alt="결과" className="mb-5 mt-5 " />
      <div
        className="w-[90%] shadow p-3 rounded flex flex-col items-center"
        style={{ boxShadow: "0px 0px 3px 0px rgba(0, 0, 0, 0.3)" }}
      >
        <img
          src={testImage}
          alt=""
          className="rounded h-full w-full aspect-square border mb-4"
          style={{ boxShadow: "0px 0px 3px 0px rgba(0, 0, 0, 0.3)" }}
        />
        <div className="font-logo text-pic-primary text-5xl mb-2">
          {score}점
        </div>
        <div className="mb-1">혹시... 전문 사진작가?</div>
      </div>

      <div className="flex  gap-10 mt-8 mb-5">
        <Button color="white" width={30} height={10} onClick={openModal}>
          <MagnifyingGlassIcon width={15} />
          <div className="ml-2">자세히</div>
        </Button>
        <Button color="green" width={30} height={10}>
          <ArrowUpTrayIcon width={15} />
          <div className="ml-2">업로드</div>
        </Button>
      </div>
      <button className="cursor-pointer flex justify-center items-center gap-1 w-30  border border-pic-primary rounded-2xl text-pic-primary mb-5">
        <ShareIcon width={15} />
        <div className="text-sm my-1">공유하기</div>
      </button>
    </div>
  );
}

export default ImageEvalResult;
