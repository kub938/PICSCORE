import ChangeInfoPage from "./ChangeInfo";

export { ChangeInfoPage };
export default ChangeInfoPage;
