function Contest() {
  return (
    <div className="bg-black w-12 h-10 border border-black">
      테스트 페이지 입니다.
    </div>
  );
}

export default Contest;
