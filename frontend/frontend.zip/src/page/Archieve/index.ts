import ArchievePage from "./Archieve";

export { ArchievePage };
export default ArchievePage;
