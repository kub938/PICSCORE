import MyPage from "./MyPage";
import UserDetailPage from "./UserDetailPage";

export { MyPage, UserDetailPage };
export default MyPage;
